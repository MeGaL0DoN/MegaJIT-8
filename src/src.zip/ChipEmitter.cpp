#include "ChipEmitter.h"
#include "ChipJITCore.h"

#ifdef _WIN32
#define ARG1 rcx
#define ARG2 rdx
#define ARG3 r8
#define ARG4 r9
#else
#define ARG1 rdi
#define ARG2 rsi
#define ARG3 rdx
#define ARG4 rcx
#endif

#define BASE rbp
#define JIT_MAP_BASE r15
#define INSTR_COUNT r12
#define I_REG_64 rbx
#define I_REG_32 ebx
#define I_REG_16 bx
#define PC_64 r13
#define PC_32 r13d
#define PC_16 r13w
#define SP_64 r14
#define SP_32 r14d
#define SP_8 r14b

#define I_REG_PTR word[BASE + offsetof(ChipState, I)]
#define PC_PTR word[BASE + offsetof(ChipState, pc)]
#define SP_PTR byte[BASE + offsetof(ChipState, sp)]

#define STACK_PTR word[BASE + offsetof(ChipState, stack) + (SP_64 * sizeof(uint16_t))]
#define KEY_PTR(offset) byte[BASE + offsetof(ChipState, keys) + offset]
#define REG_PTR(num) byte[BASE + offsetof(ChipState, V) + num]
#define RAM_PTR(offset) byte[BASE + I_REG_64 + offsetof(ChipState, RAM) + offset]
#define SCREEN_PTR(offset) ptr[BASE + offsetof(ChipState, screenBuffer) + (offset * sizeof(uint64_t))]

#define EXECUTE_FLAG_PTR byte[BASE + offsetof(ChipState, executeFlag)]

constexpr int WIN_SHADOW_SPACE { 32 };

template <typename F>
uint64_t funcAddr(F func)
{
	uint64_t addr;
	std::memcpy(&addr, &func, sizeof(addr));
	return addr;
}

void ChipEmitter::reset()
{
	instructions = 0;
	branchedInstrs = 0;
	blockHasInstrSkips = false;
}

void ChipEmitter::emitUncompiledBlockHandler()
{
	mov(ARG1, reinterpret_cast<uint64_t>(&core));
	mov(ARG2, PC_64);
	callFunc(funcAddr(&ChipJITCore::compileBlock));
	//int3();
	jmp(rax);
}

void ChipEmitter::emitDispatcher()
{
	push(rbx);
	push(rbp);
	push(r12);
	push(r13);
	push(r14);
	push(r15);

#ifdef _WIN32
	sub(rsp, 168);

	for (int i = 6; i <= 15; i++)
		movdqa(ptr[rsp + (i - 6) * 16], V_REGS[i]); // save xmm6-15
#else
	sub(rsp, 8); // 16-byte alignment
#endif

	mov(BASE, reinterpret_cast<uint64_t>(&core.s));
	const int32_t offsetToJITMap = reinterpret_cast<uint64_t>(&core.JIT.blockMap) - reinterpret_cast<uint64_t>(&core.s);

	//mov(JIT_MAP_BASE, reinterpret_cast<uint64_t>(&core.JIT.blockMap));

	movzx(I_REG_32, I_REG_PTR);
	movzx(PC_32, PC_PTR);
	movzx(SP_32, SP_PTR);
	xor_(INSTR_COUNT, INSTR_COUNT);

	for (int i = 0; i < 16; i++)
	{
		movzx(eax, REG_PTR(i));
		movd(V_REGS[i], eax);
	}

	L(dispatcherLoop);
	//jmp(qword[JIT_MAP_BASE + (PC_64 * 8)]);
	jmp(qword[BASE + offsetToJITMap + (PC_64 * 8)]);
	L(dispatcherEnd);

	mov(I_REG_PTR, I_REG_16);
	mov(PC_PTR, PC_16);
	mov(SP_PTR, SP_8);

	for (int i = 0; i < 16; i++)
	{
		movd(eax, V_REGS[i]);
		mov(REG_PTR(i), al);
	}

#ifdef _WIN32
	for (int i = 6; i <= 15; i++)
		movdqa(V_REGS[i], ptr[rsp + (i - 6) * 16]);

	add(rsp, 168);
#else
	add(rsp, 8);
#endif

	mov(rax, INSTR_COUNT);

	pop(r15);
	pop(r14);
	pop(r13);
	pop(r12);
	pop(rbp);
	pop(rbx);
	ret();
}

void ChipEmitter::callFunc(uint64_t func) // todo save XMM's
{
#ifdef _WIN32
	sub(rsp, WIN_SHADOW_SPACE + 6 * 16);

	for (int i = 0; i <= 5; i++)
		movdqa(ptr[rsp + WIN_SHADOW_SPACE + i * 16], V_REGS[i]); // save xmm0-5
#endif
	mov(rax, func);
	call(rax);
#ifdef _WIN32
	for (int i = 0; i <= 5; i++)
		movdqa(V_REGS[i], ptr[rsp + WIN_SHADOW_SPACE + i * 16]); 

	add(rsp, WIN_SHADOW_SPACE + 6 * 16);
#endif
}

void ChipEmitter::emitBlockInvalidation(int count, uint16_t pc)
{
	mov(ARG1, reinterpret_cast<uint64_t>(&core));
	mov(ARG2, I_REG_64);
	lea(ARG3, ptr[ARG2 + count]);
	callFunc(funcAddr(&ChipJITCore::invalidateBlocks));

	Xbyak::Label noSelfModifyingCode;
	test(al, al);
	jz(noSelfModifyingCode);
	// early block end if self-modifying code has occurred.
	emitEpilogue(pc);
	L(noSelfModifyingCode);
}

void ChipEmitter::emitIllegalOPHandler()
{
	mov(ARG1, reinterpret_cast<uint64_t>(&core));
	callFunc(funcAddr(&ChipJITCore::illegalOpcodeHandler));
}

void ChipEmitter::emitBreakpoint() 
{
	int3(); 
}

void ChipEmitter::emitEpilogue(uint16_t pc)
{
	add(INSTR_COUNT, instructions - branchedInstrs);

	if (pc != static_cast<uint16_t>(-1))
		mov(PC_32, pc);

	cmp(EXECUTE_FLAG_PTR, 0);
	jnz(dispatcherLoop);
	jmp(dispatcherEnd);
}

uint8_t* ChipEmitter::emitJumpPlaceholder()
{
	db(0xE9);
	dd(0);
	return getCodeEndPtr();
}
void ChipEmitter::patchBranchInstr(uint8_t* branchCodeEndPtr, bool incBeforeBranch)
{
	constexpr auto INC_R64_SIZE { 3 };
	const auto offset { incBeforeBranch ? INC_R64_SIZE : 0 };

	int32_t* jumpOffsetPtr { reinterpret_cast<int32_t*>(branchCodeEndPtr - offset - sizeof(int32_t)) };
	const int32_t jumpOffset { static_cast<int32_t>(getCodeEndPtr() - branchCodeEndPtr + offset) };
	*jumpOffsetPtr = jumpOffset;
}

void ChipEmitter::emitInstrCountAdd(int32_t instrs)
{
	add(INSTR_COUNT, instrs);
}
void ChipEmitter::emitInstrCountAddPlaceholder()
{
	add(INSTR_COUNT, INT32_MAX);
}
void ChipEmitter::patchAddImm32(uint8_t* addCodeEndPtr, int32_t imm)
{
	*reinterpret_cast<int32_t*>(addCodeEndPtr - sizeof(int32_t)) = imm;
}

#define quirks core.s.quirks

void ChipEmitter::emit00E0()
{
	movd(eax, xmm0); 

	if (avxSupport)
	{
		vxorpd(ymm0, ymm0, ymm0);

		for (int i = 0; i < 32; i += 4)
			vmovdqu(SCREEN_PTR(i), ymm0);

		vzeroupper();
	}
	else
	{
		pxor(xmm0, xmm0);

		for (int i = 0; i < 32; i += 2)
			movdqu(SCREEN_PTR(i), xmm0);
	}

	movd(xmm0, eax); 
}

void ChipEmitter::emit00EE()
{
	dec(SP_8);
	movzx(PC_32, STACK_PTR);
}

void ChipEmitter::emit1NNN(uint16_t addr)
{
	mov(PC_32, addr);
}

void ChipEmitter::emit2NNN(uint16_t addr, uint16_t pc)
{
	mov(STACK_PTR, pc);
	mov(PC_32, addr);
	inc(SP_8);
}

void ChipEmitter::emit5XY0(uint8_t x, uint8_t y, bool incBranches)
{
	movd(eax, V_REGS[x]);
	movd(ecx, V_REGS[y]);
	cmp(eax, ecx);
	// jz
	db(0x0F);
	db(0x84);
	dd(0); // reserve 4 bytes for offset

	if (incBranches)
		inc(INSTR_COUNT);
}
void ChipEmitter::emit9XY0(uint8_t x, uint8_t y, bool incBranches)
{
	movd(eax, V_REGS[x]);
	movd(ecx, V_REGS[y]);
	cmp(eax, ecx);
	// jnz
	db(0x0F);
	db(0x85);
	dd(0);

	if (incBranches)
		inc(INSTR_COUNT);
}
void ChipEmitter::emit3XNN(uint8_t x, uint8_t val, bool incBranches)
{
	movd(eax, V_REGS[x]);
	cmp(al, val);
	// jz
	db(0x0F);
	db(0x84);
	dd(0);

	if (incBranches)
		inc(INSTR_COUNT);
}
void ChipEmitter::emit4XNN(uint8_t x, uint8_t val, bool incBranches)
{
	movd(eax, V_REGS[x]);
	cmp(al, val);
	// jnz
	db(0x0F);
	db(0x85);
	dd(0);

	if (incBranches)
		inc(INSTR_COUNT);
}

void ChipEmitter::emitEX9E(uint8_t x, bool incBranches)
{
	movd(ecx, V_REGS[x]);
	and_(ecx, 0xF);
	movzx(ecx, KEY_PTR(rcx));
	test(ecx, ecx);
	// jnz
	db(0x0F);
	db(0x85);
	dd(0);

	if (incBranches)
		inc(INSTR_COUNT);
}
void ChipEmitter::emitEXA1(uint8_t x, bool incBranches)
{
	movd(ecx, V_REGS[x]);
	and_(ecx, 0xF);
	movzx(ecx, KEY_PTR(rcx));
	test(ecx, ecx);
	// jz
	db(0x0F);
	db(0x84);
	dd(0);

	if (incBranches)
		inc(INSTR_COUNT);
}

void ChipEmitter::emit6XNN(uint8_t x, uint8_t val)
{
	mov(eax, val);
	movd(V_REGS[x], eax);
}

void ChipEmitter::emit7XNN(uint8_t x, uint8_t val)
{
	movd(eax, V_REGS[x]);
	add(al, val);
	movd(V_REGS[x], eax);
}

void ChipEmitter::emit8XY0(uint8_t x, uint8_t y)
{
	movdqa(V_REGS[x], V_REGS[y]);
}
void ChipEmitter::emit8XY1(uint8_t x, uint8_t y, bool calcFlag)
{
	por(V_REGS[x], V_REGS[y]);

	if (quirks.vfReset && calcFlag)
		pxor(V_REGS[0xF], V_REGS[0xF]);
}
void ChipEmitter::emit8XY2(uint8_t x, uint8_t y, bool calcFlag)
{
	pand(V_REGS[x], V_REGS[y]);

	if (quirks.vfReset && calcFlag)
		pxor(V_REGS[0xF], V_REGS[0xF]);
}
void ChipEmitter::emit8XY3(uint8_t x, uint8_t y, bool calcFlag)
{
	pxor(V_REGS[x], V_REGS[y]);

	if (quirks.vfReset && calcFlag)
		pxor(V_REGS[0xF], V_REGS[0xF]);
}
void ChipEmitter::emit8XY4(uint8_t x, uint8_t y, bool calcFlag)
{
	if (x == 0xF && !calcFlag)
		return;

	if (calcFlag)
	{
		movd(eax, V_REGS[x]);
		movd(ecx, V_REGS[y]);
		add(al, cl);
		setc(cl);
		movd(V_REGS[0xF], ecx);

		if (x != 0xF)
			movd(V_REGS[x], eax);
	}
	else
		paddb(V_REGS[x], V_REGS[y]);
}
void ChipEmitter::emit8XY5(uint8_t x, uint8_t y, bool calcFlag)
{
	if (x == 0xF && !calcFlag)
		return;

	if (calcFlag)
	{
		movd(eax, V_REGS[x]);
		movd(ecx, V_REGS[y]);
		sub(al, cl);
		setnc(cl);
		movd(V_REGS[0xF], ecx);

		if (x != 0xF)
			movd(V_REGS[x], eax);
	}
	else
		psubb(V_REGS[x], V_REGS[y]);
}
void ChipEmitter::emit8XY6(uint8_t x, uint8_t y, bool calcFlag)
{
	if (x == 0xF)
	{
		if (calcFlag)
		{
			if (!quirks.shifting && y != 0xF)
				movdqa(V_REGS[0xF], V_REGS[y]);

			pslld(V_REGS[0xF], 31);
			psrld(V_REGS[0xF], 31);
		}
	}
	else
	{
		if (!quirks.shifting && x != y)
			movdqa(V_REGS[x], V_REGS[y]);

		if (calcFlag)
		{
			movdqa(V_REGS[0xF], V_REGS[x]);
			pslld(V_REGS[0xF], 31);
			psrld(V_REGS[0xF], 31);
		}
		
		psrld(V_REGS[x], 1);
	}
}
void ChipEmitter::emit8XY7(uint8_t x, uint8_t y, bool calcFlag)
{
	if (x == 0xF && !calcFlag)
		return;

	movd(ecx, V_REGS[x]);
	movd(eax, V_REGS[y]);
	sub(al, cl);

	if (calcFlag)
	{
		setnc(cl);
		movd(V_REGS[0xF], ecx);
	}
	if (x != 0xF)
		movd(V_REGS[x], eax);
}

void ChipEmitter::emit8XYE(uint8_t x, uint8_t y, bool calcFlag)
{
	if (x == 0xF)
	{
		if (calcFlag)
		{
			if (!quirks.shifting && y != 0xF)
				movdqa(V_REGS[0xF], V_REGS[y]);

			psrld(V_REGS[0xF], 7);
		}
	}
	else
	{
		if (!quirks.shifting && x != y)
			movdqa(V_REGS[x], V_REGS[y]);

		if (calcFlag)
		{
			movdqa(V_REGS[0xF], V_REGS[x]);
			psrld(V_REGS[0xF], 7);
		}
		
		paddb(V_REGS[x], V_REGS[x]); // same as left shift by 1
	}
}

void ChipEmitter::emitANNN(uint16_t val)
{
	mov(I_REG_32, val);
}

void ChipEmitter::emitBNNN(uint16_t addr, uint8_t x)
{
	movd(PC_32, quirks.jumping ? V_REGS[x] : V_REGS[0]);
	add(PC_32, addr);
	and_(PC_32, 0xFFF);
}

void ChipEmitter::emitCXNN(uint8_t x, uint8_t val)
{
	rdtsc(); // using cpu timestamp as a random number
	and_(eax, val);
	movd(V_REGS[x], eax);
}

void ChipEmitter::emitDXYN(uint8_t x, uint8_t y, uint8_t n, bool calcFlag)
{
	if (n == 0)
	{
		if (calcFlag)
			pxor(V_REGS[0xF], V_REGS[0xF]);

		return;
	}

	Xbyak::Label loopEnd;

	movd(ecx, V_REGS[x]);
	and_(ecx, (ChipState::SCR_WIDTH - 1));

	movd(eax, V_REGS[y]);
	and_(eax, (ChipState::SCR_HEIGHT - 1));

	if (calcFlag)
		pxor(V_REGS[0xF], V_REGS[0xF]);

	for (int i = 0; i < n; i++)
	{
		movzx(edx, RAM_PTR(i));

		if (calcFlag)
			mov(r8, SCREEN_PTR(rax));

		shl(rdx, ChipState::SCR_WIDTH - 8);

		if (quirks.clipping)
			shr(rdx, cl);
		else
			ror(rdx, cl);

		if (calcFlag)
		{
			test(r8, rdx);
			Xbyak::Label skip;
			jz(skip);
			pcmpeqd(V_REGS[0xF], V_REGS[0xF]);
			psrld(V_REGS[0xF], 31);
			L(skip);
			xor_(r8, rdx);
			mov(SCREEN_PTR(rax), r8);
		}
		else
			xor_(SCREEN_PTR(rax), rdx);

		if (i != (n - 1))
		{
			if (quirks.clipping)
			{
				cmp(eax, (ChipState::SCR_HEIGHT - 1));
				je(loopEnd, T_NEAR);
				inc(eax);
			}
			else
			{
				inc(eax);
				and_(eax, (ChipState::SCR_HEIGHT - 1));
			}
		}
	}

	L(loopEnd);
}

void ChipEmitter::emitFX07(uint8_t x)
{
	movzx(eax, byte[BASE + offsetof(ChipState, delayTimer)]);
	movd(V_REGS[x], eax);
}
void ChipEmitter::emitFX15(uint8_t x)
{
	movd(eax, V_REGS[x]);
	mov(byte[BASE + offsetof(ChipState, delayTimer)], al);
}
void ChipEmitter::emitFX18(uint8_t x)
{
	movd(eax, V_REGS[x]);
	mov(byte[BASE + offsetof(ChipState, soundTimer)], al);
}

void ChipEmitter:: emitFX1E(uint8_t x)
{
	movd(eax, V_REGS[x]);
	add(I_REG_32, eax);
	and_(I_REG_32, 0xFFF);
}

void ChipEmitter::emitFX29(uint8_t x)
{
	movd(eax, V_REGS[x]);
	and_(eax, 0xF);
	lea(I_REG_32, ptr[rax + (rax * 4)]);
}

void ChipEmitter::emitFX33(uint8_t x, uint16_t pc)
{
	Xbyak::Label end;
	movd(eax, V_REGS[x]);

	lea(edx, ptr[rax + 4 * rax]);
	lea(ecx, ptr[rax + 8 * rdx]);
	shr(ecx, 12);
	mov(RAM_PTR(0), cl);
	cmp(I_REG_32, 0xFFF);
	je(end, T_NEAR);
	imul(ecx, eax, 205);
	shr(ecx, 11);
	lea(edx, ptr[rcx + 4 * rcx]);
	lea(edx, ptr[rdx + 4 * rdx]);
	add(edx, ecx);
	shr(edx, 7);
	and_(edx, 6);
	lea(edx, ptr[rdx + 4 * rdx]);
	mov(r8d, ecx);
	sub(r8b, dl);
	mov(RAM_PTR(1), r8b);
	cmp(I_REG_32, 0xFFE);
	je(end, T_NEAR);
	add(ecx, ecx);
	lea(ecx, ptr[rcx + 4 * rcx]);
	sub(al, cl);
	mov(RAM_PTR(2), al);

	L(end);
	emitBlockInvalidation(2, pc);
}

void ChipEmitter::emitFX55(uint8_t x, uint16_t pc) 
{
	Xbyak::Label end;

	cmp(I_REG_32, 0xFFF - x);
	ja(end, T_NEAR);

	for (int i = 0; i <= x; i++)
	{
		movd(eax, V_REGS[i]);
		mov(RAM_PTR(i), al);
	}

	emitBlockInvalidation(x, pc);

	if (quirks.memoryIncrement)
	{
		add(I_REG_32, x + 1);
		and_(I_REG_32, 0xFFF);
	}

	L(end);
}
void ChipEmitter::emitFX65(uint8_t x)
{
	Xbyak::Label end;

	for (int i = 0; i <= x; i++)
	{
		movzx(eax, RAM_PTR(i));
		movd(V_REGS[i], eax);
	}

	if (quirks.memoryIncrement)
	{
		add(I_REG_32, x + 1);
		and_(I_REG_32, 0xFFF);
	}

	L(end);
}

void ChipEmitter::emitFX0A(uint8_t x, uint16_t pc) 
{
	Xbyak::Label firstCall, end;

	mov(PC_32, pc - 2);
	cmp(byte[BASE + offsetof(ChipState, firstFX0ACall)], 1);
	jz(firstCall);

	cmp(byte[BASE + offsetof(ChipState, inputReg)], -1);
	jnz(end);
	movzx(eax, REG_PTR(x));
	movd(V_REGS[x], eax);
	mov(byte[BASE + offsetof(ChipState, firstFX0ACall)], 1);
	add(PC_32, 2);
	jmp(end);

	L(firstCall);
	mov(byte[BASE + offsetof(ChipState, inputReg)], x);
	mov(byte[BASE + offsetof(ChipState, firstFX0ACall)], 0);

	L(end);
}